falta
//(despues)tuplas en listas en c# en API login

//(después)confiar en certificado base de datos API login

// (despues)bytes en hexadecimal en string en vez de base64 para simplicidad

//(despues)mover archivos en servidor para renombrar papeletas y darlas por el API

// API para registrar el voto

// API para estadisticas

// arreglar html

// separar css en global y local

// hacer javascript de login, papeleta

// hacer variante para desarrollo 5 que solo valide la cédula y el código de la cédula pero no la revisa con bd

// hacer trabajo escrito

// hacer Canva

// hacer wireframes

