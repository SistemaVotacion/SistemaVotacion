﻿using Microsoft.EntityFrameworkCore;

namespace API_VotoTotal.Models
{
    [Keyless]

    public class VotosTotales
    {
        public int VotosTodosCandidatos { get; set; }

    }

}
